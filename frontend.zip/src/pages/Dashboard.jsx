import React from 'react'

const Dashboard = () => {
  return (
    <div>
        <h1>Hello this is dashboard</h1>
    </div>
  )
}

export default Dashboard